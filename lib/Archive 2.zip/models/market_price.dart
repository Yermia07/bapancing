class MarketPrice {
  final String species;
  final int price;

  MarketPrice({
    required this.species,
    required this.price,
  });
}
